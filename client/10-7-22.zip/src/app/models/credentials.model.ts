export class CredentialsModel {
    public username: string;
    public password: string;
}
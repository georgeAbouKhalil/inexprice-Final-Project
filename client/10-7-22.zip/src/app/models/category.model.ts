export class CategoryModel {
    _id?: string;
    name: string
}
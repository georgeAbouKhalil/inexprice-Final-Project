export class ItemModel {

    user: string;
    room: string;
    message: string;
    Date: string;
    Time: string;
}
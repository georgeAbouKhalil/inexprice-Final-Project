export class UserModel {
    _id?: string;
    firstName: string;
    lastName: string;
    email: string;
    address: string;
    city: string;
    birthday: string;
    country: string;
    userName: string;
    password: string;
    gender: string;
    business: string;
    role: string;
    phone: string;
    favorite:object;
}
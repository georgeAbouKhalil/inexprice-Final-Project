export class CartModel {
    _id?: string;
    user_id?: string;
    status?: string
}